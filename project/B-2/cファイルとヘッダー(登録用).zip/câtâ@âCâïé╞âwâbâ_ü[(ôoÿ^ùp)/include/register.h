﻿#ifndef register_h
#define register_h

void New_register();
void register_add();
void update();

#endif