﻿#include "inputcansel.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include <stdlib.h>

bool cansel_kanji_and_katakana(const char* name) {
    // 漢字・カタカナの検証ロジックを実装
    // 例: 正規表現や文字コードの範囲チェックを行う
    return true; // 仮の実装
}

bool cansel_hankaku_8number(int* exam_date) {
    if (strlen(exam_date) != 8) return false;
    for (int i = 0; i < 8; i++) {
        if (!isdigit(exam_date[i])) return false;
    }
    return true;
}

bool cansel_hiragana_igai(const char* furigana) {
    // ひらがなの検証ロジックを実装
    // 例: 文字コードの範囲チェックを行う
    return true; // 仮の実装
}

int ishiragana_utf8(const char* str) {
    const unsigned char* p = (const unsigned char*)str;

    while (*p) {
        if ((p[0] & 0xF0) == 0xE0) {
            // UTF-8の3バイト文字をUnicodeに変換
            unsigned int unicode = ((p[0] & 0x0F) << 12) |
                ((p[1] & 0x3F) << 6) |
                (p[2] & 0x3F);

            // ひらがなUnicode範囲: U+3041〜U+3096
            if (unicode >= 0x3041 && unicode <= 0x3096) {
                p += 3;
            }
            else {
                return 0;
            }
        }
        else {
            return 0; // UTF-8の3バイト文字以外はNG
        }
    }

    return 1;
}
