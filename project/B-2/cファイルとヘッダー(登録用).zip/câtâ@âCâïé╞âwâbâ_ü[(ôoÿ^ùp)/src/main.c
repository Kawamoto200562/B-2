#include <stdio.h>
#include <string.h>

int main(void) {
    char name[60];
    char furigana[60];

    printf("氏名入力\n");
    scanf_s("%59s", name);
    getchar();

    printf("フリガナ入力\n");
    scanf_s("%59s", furigana);

    printf("%s,%s", name, furigana);
    return 0;
}
