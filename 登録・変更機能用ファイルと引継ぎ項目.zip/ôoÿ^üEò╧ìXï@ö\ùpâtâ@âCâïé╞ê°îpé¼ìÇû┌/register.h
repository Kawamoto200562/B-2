﻿#ifndef register_h
#define register_h

void New_register();
void Add_register();
void update();

#endif